/*
 AIClassFrame.java

*/

public
class AIClassFrame extends AIFrame {

public
AIClassFrame(
 AIFrameSystem inFrameSystem,
 AIClassFrame inSuperFrame,
 String inName ) {
 super( inFrameSystem, inSuperFrame, inName, false );
}
 
}